UPDATE `creature_ai_scripts` SET `event_param3`='10000', `event_param4`='10000' WHERE (`id`='2112605');
UPDATE `creature_ai_scripts` SET `event_param3`='10000', `event_param4`='10000' WHERE (`id`='2112606');
UPDATE `creature_ai_scripts` SET `action1_param2`='0' WHERE (`id`='2112603');
UPDATE `creature_ai_scripts` SET `action1_param2`='0' WHERE (`id`='2112604');