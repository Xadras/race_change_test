UPDATE `gameobject_template` SET type = 3 WHERE entry = 180453;
UPDATE `gameobject_template` SET data0 = 57 WHERE entry = 180453;
UPDATE `gameobject_template` SET data1 = 27357 WHERE entry = 180453;
UPDATE `gameobject_template` SET type = 3 WHERE entry = 180454;
UPDATE `gameobject_template` SET data0 = 57 WHERE entry = 180454;
UPDATE `gameobject_template` SET data1 = 27358 WHERE entry = 180454;
UPDATE `gameobject_template` SET type = 3 WHERE entry = 180455;
UPDATE `gameobject_template` SET data0 = 57 WHERE entry = 180455;
UPDATE `gameobject_template` SET data1 = 27359 WHERE entry = 180455;

INSERT INTO `gameobject_loot_template`
(`entry`,`item`,`ChanceOrQuestChance`,`Groupid`,`MincountOrRef`,`Maxcount`,`Lootcondition`,`Condition_value1`,
`Condition_value2`) VALUES
(27357,20456,-100,0,1,1,0,0,0),
(27358,20455,-100,0,1,1,0,0,0),
(27359,20454,-100,0,1,1,0,0,0);