INSERT INTO `spell_proc_event` (`entry`, `procFlags`) VALUES ('15270', '2');
INSERT INTO `spell_proc_event` (`entry`, `procFlags`) VALUES ('15338', '2');
INSERT INTO `spell_proc_event` (`entry`, `procFlags`) VALUES ('15337', '2');
INSERT INTO `spell_proc_event` (`entry`, `procFlags`) VALUES ('15336', '2');
INSERT INTO `spell_proc_event` (`entry`, `procFlags`) VALUES ('15335', '2');