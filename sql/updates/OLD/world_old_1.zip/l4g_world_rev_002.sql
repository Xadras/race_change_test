-- weapons for M'uru adds
insert into creature_equip_template values
(2238, 46863, 0, 0, 285280770, 0, 0, 529, 0, 0),
(2239, 46970, 46970, 0, 218171138, 218171138, 0, 3, 3, 0);

update creature_template set equipment_id = 2238 where entry = 25799;
update creature_template set equipment_id = 2239 where entry = 25798;

-- FS#164 rare mobs loot (bloodmyst,eversong,ghostlands,alterac,arathi,ashenvale,azshara)
delete from creature_loot_template where item in (6327,1678,6331,5257);
insert into creature_loot_template values
(22060,31256,0,2,1,1,0,0,0),(22060,31263,0,2,1,1,0,0,0),(22060,31264,0,2,1,1,0,0,0), -- Fenissa the assassin
(22062,31268,0,2,1,1,0,0,0),(22062,31269,0,2,1,1,0,0,0),(22062,31270,0,2,1,1,0,0,0), -- Dr. Whitherlimb
(2453,6327,14,2,1,1,0,0,0),(2453,1678,38,2,1,1,0,0,0),(2453,4810,48,2,1,1,0,0,0), -- Lo'grosh
(2452,6331,25,2,1,1,0,0,0),(2452,3011,75,2,1,1,0,0,0), -- Skhowl
(2609,5742,45,2,1,1,0,0,0),(2609,5743,35,2,1,1,0,0,0), -- Geomancer Flintdagger
(2603,5256,25,0,1,1,0,0,0),(2606,5257,11.1,2,1,1,0,0,0),(2606,2622,88.9,2,1,1,0,0,0), -- Kovork; Nimar the Slayer
(2600,5180,25,2,1,1,0,0,0),(2600,5180,75,2,1,1,0,0,0); -- Singer
delete from reference_loot_template where item in
(31256,31263,31264, -- Fenissa the assassin
31268,31269,31270, -- Dr. Whitherlimb
4810,3011,5256,2622,-- Lo'grosh ;Skhowl; Kovork; Nimar the Slayer
5180,5181); -- Singer
update creature_loot_template set ChanceOrQuestChance=0 where
(entry in (3773,3736,10641,10639) and item in (24064,24066,24068))
or (entry=3735 and item in (24060,24062,24064,24066,24068))
or (entry in (10640,10642) and item in (24048,24066,24068))
or (entry in (10559,10644) and item in (24060,24062,24064,24066))
or (entry=10643 and item in (24062,24063,24064,24066))
or (entry=10647 and item in (24048,24050,24051,24052,24053))
or (entry=3792 and item in (24048,24050,24051,24052))
or (entry=12037 and item in (24048,24050,24052))
or (entry in (6648,6651) and item in (24025,24027,24045))
or (entry=6650 and item in (24025,24027,24029,24045,24046))
or (entry=6649 and item in (24025,24027,24029,24026))
or (entry in (6649,6652) and item in (24025,24027,24029))
or (entry=6646 and item in (24025,24027,24029,24031))
or (entry=13896 and item in (24025,24027,24029,24028))
or (entry in (8660,6118) and item in (24025,24045,24043));

-- Magtheridon's Lair: No gold from adds
UPDATE `creature_template` SET `mingold` = 0, `maxgold` = 0 WHERE `entry` = 17256;

-- Remove redundant referenced recipe loot
DELETE FROM `creature_loot_template` WHERE `mincountOrRef` = -50031 LIMIT 10;
DELETE FROM `reference_loot_template` WHERE `entry` = 50031;

-- Bump recipe group chance to 10%, so there is 1% per single recipe to appear
UPDATE `creature_loot_template` SET `ChanceOrQuestChance` = 10 WHERE `mincountOrRef` = -34011 LIMIT 10;

-- Karazhan: Fix reputation reward for quest The Master's Terrace
UPDATE `quest_template` SET `RewRepFaction1` = 967, `RewRepValue1` = 250 WHERE `entry` = 9645;

-- Weapons & HP for Nethermancer Sepethrea
insert into creature_equip_template values
(2042, 36442, 44544, 0, 218171138, 386007044, 0, 3, 3, 0);
update creature_template set equipment_id = 2042 where entry in (19221, 21536);
update creature_template set minhealth = 174650, maxhealth = 174650 where entry = 19221;
update creature_template set minhealth = 250920, maxhealth = 250920 where entry = 21536;
-- Raging Fires make fire dmg
update creature_template set dmgschool = 2 where entry in (20481, 21538);
update creature_template set minhealth = 164390, maxhealth = 164390, mindmg = 520, maxdmg = 800 where entry = 21538;
update creature_template set minhealth = 115269, maxhealth = 115269 where entry = 20481;

update script_texts set type = 6 where sound <>0;
update script_texts set type = 1 where entry =-1811003;
update script_texts set type = 2 where entry =-1811001;
update script_texts set type = 1 where entry >-1563017 and entry <-1563000;

INSERT INTO `creature` VALUES
(NULL, 15930, 533, 1, 0, 0, 3507.04, -2990.41, 312.005, 2.34683, 6380, 0, 0, 499650, 0, 0, 0);

update script_texts set type=1 where sound and entry >-1000396 and entry <-1000374;
update script_texts set content_default ='Stay on task! Do not waste time!' where entry = -1580067;

