CREATE TABLE `character_quest` (
`guid`  int(11) UNSIGNED NOT NULL ,
`show_low_level_quest`  tinyint(1) UNSIGNED NULL DEFAULT 0 ,
PRIMARY KEY (`guid`)
)
;