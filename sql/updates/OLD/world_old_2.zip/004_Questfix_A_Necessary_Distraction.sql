--Questfix A Necessary Distraction
UPDATE `quest_template` SET `ReqSpellCast1`='37834' WHERE (`entry`='10688') LIMIT 1;