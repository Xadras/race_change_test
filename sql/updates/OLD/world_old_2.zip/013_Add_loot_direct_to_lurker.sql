UPDATE `creature_template` SET `lootid`='21217' WHERE (`entry`='21217');
