-- nhc creature
INSERT INTO `creature_template` (`entry`, `heroic_entry`, `KillCredit`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `IconName`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `xp_modifier`, `faction_A`, `faction_H`, `npcflag`, `speed`, `scale`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `unit_flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `type_flags`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `spell5`, `PetSpellDataId`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `mechanic_immune_mask`, `flags_extra`, `ScriptName`) VALUES 
('91598', '28132', NULL, '25124', '0', '25124', '0', 'Don Carlos', '', '', '68', '68', '41154', '41154', '0', '0', '3987', '1', '1748', '1748', '3', '1', '1', '1', '600', '1000', '0', '0', '1500', '2000', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '7', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', '0', 'EventAI', '0', '3', '0', '1', '413', '80428891', '0', '');

-- spawns
INSERT INTO `creature` VALUES (16800079, 91598, 560, 1, 0, 413, 2194.89, 1024.53, 48.2594, 5.96866, 100000, 0, 0, 41154, 0, 0, 0);
INSERT INTO `creature` VALUES (16800080, 91598, 560, 2, 0, 413, 2191.23, 1024.94, 47.6858, 2.74224, 100000, 0, 0, 109852, 0, 0, 0);

-- spells
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813201') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813202') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813203') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813204') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813205') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813206') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813207') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813208') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813209') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813210') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813211') LIMIT 1;
UPDATE `creature_ai_scripts` SET `entryOrGUID`='91598' WHERE (`id`='2813212') LIMIT 1;

-- nhc loot
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `groupid`, `mincountOrRef`, `maxcount`, `lootcondition`, `condition_value1`, `condition_value2`) VALUES
(91598,24765,0.02,0,1,1,0,0,0),
(91598,24667,0.02,0,1,1,0,0,0),
(91598,25357,0.02,0,1,1,0,0,0),
(91598,25396,0.02,0,1,1,0,0,0),
(91598,25390,0.03,0,1,1,0,0,0),
(91598,25392,0.03,0,1,1,0,0,0),
(91598,25152,0.09,0,1,1,0,0,0),
(91598,25405,0.09,0,1,1,0,0,0),
(91598,25400,0.09,0,1,1,0,0,0),
(91598,25402,0.09,0,1,1,0,0,0),
(91598,25304,0.1,0,1,1,0,0,0),
(91598,25053,0.1,0,1,1,0,0,0),
(91598,25377,0.1,0,1,1,0,0,0),
(91598,25378,0.1,0,1,1,0,0,0),
(91598,25360,0.1,0,1,1,0,0,0),
(91598,25361,0.1,0,1,1,0,0,0),
(91598,25344,0.1,0,1,1,0,0,0),
(91598,25345,0.1,0,1,1,0,0,0),
(91598,25362,0.12,0,1,1,0,0,0),
(91598,25082,0.14,0,1,1,0,0,0),
(91598,25375,0.14,0,1,1,0,0,0),
(91598,25363,0.14,0,1,1,0,0,0),
(91598,25342,0.14,0,1,1,0,0,0),
(91598,25341,0.15,0,1,1,0,0,0),
(91598,25398,0.15,0,1,1,0,0,0),
(91598,25401,0.19,0,1,1,0,0,0),
(91598,25399,0.2,0,1,1,0,0,0),
(91598,25403,0.2,0,1,1,0,0,0),
(91598,25404,0.3,0,1,1,0,0,0),
(91598,22832,0.4,0,1,1,0,0,0),
(91598,25389,0.4,0,1,1,0,0,0),
(91598,30457,1.4,0,1,1,0,0,0),
(91598,30458,3,0,1,1,0,0,0),
(91598,21877,13,0,2,3,0,0,0),
(91598,38329,31,0,1,1,0,0,0);

-- hc loot
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `groupid`, `mincountOrRef`, `maxcount`, `lootcondition`, `condition_value1`, `condition_value2`) VALUES
(28132,25391,0.02,0,1,1,0,0,0),
(25132,24912,0.04,0,1,1,0,0,0),
(28132,25084,0.04,0,1,1,0,0,0),
(28132,24685,0.1,0,1,1,0,0,0),
(28132,24911,0.1,0,1,1,0,0,0),
(28132,25376,0.1,0,1,1,0,0,0),
(28132,25373,0.1,0,1,1,0,0,0),
(28132,25377,0.1,0,1,1,0,0,0),
(28132,25363,0.1,0,1,1,0,0,0),
(28132,24341,0.1,0,1,1,0,0,0),
(28132,25393,0.12,0,1,1,0,0,0),
(28132,25364,0.12,0,1,1,0,0,0),
(28132,25346,0.14,0,1,1,0,0,0),
(28132,25014,0.14,0,1,1,0,0,0),
(28132,25395,0.14,0,1,1,0,0,0),
(28132,25390,0.14,0,1,1,0,0,0),
(28132,25406,0.14,0,1,1,0,0,0),
(28132,24686,0.16,0,1,1,0,0,0),
(28132,25020,0.16,0,1,1,0,0,0),
(28132,25362,0.16,0,1,1,0,0,0),
(28132,31883,0.18,0,1,1,0,0,0),
(28132,25396,0.18,0,1,1,0,0,0),
(28132,25342,0.18,0,1,1,0,0,0),
(28132,25056,0.2,0,1,1,0,0,0),
(28132,25402,0.2,0,1,1,0,0,0),
(28132,25399,0.2,0,1,1,0,0,0),
(28132,25379,0.2,0,1,1,0,0,0),
(28132,25358,0.2,0,1,1,0,0,0),
(28132,25405,0.2,0,1,1,0,0,0),
(28132,25729,0.3,0,1,1,0,0,0),
(28132,22832,0.3,0,1,1,0,0,0),
(28132,25404,0.3,0,1,1,0,0,0),
(28132,25398,0.3,0,1,1,0,0,0),
(28132,25400,0.4,0,2,3,0,0,0),
(28132,25403,0.4,0,1,1,0,0,0),
(28132,25401,0.5,0,1,1,0,0,0),
(28132,30457,1.6,0,1,1,0,0,0),
(28132,30458,3,0,2,3,0,0,0),
(28132,38329,20,0,1,1,0,0,0),
(28132,21877,20,0,2,3,0,0,0),
(28131,38506,80,0,1,1,0,0,0);

-- assign loot to both nh and hc
UPDATE `creature_template` SET `lootid`='28132' WHERE (`entry`='28132') LIMIT 1;
UPDATE `creature_template` SET `lootid`='91598' WHERE (`entry`='91598') LIMIT 1;