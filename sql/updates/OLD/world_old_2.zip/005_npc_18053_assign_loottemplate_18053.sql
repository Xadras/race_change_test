-- assign Loottemplate 18053
UPDATE `creature_template` SET `lootid`='18053' WHERE (`entry`='18053') LIMIT 1