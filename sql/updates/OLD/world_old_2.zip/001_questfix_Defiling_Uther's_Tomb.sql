UPDATE `spell_script_target` SET `type` = '0',
`targetEntry` = '181653' WHERE `spell_script_target`.`entry` =30098 AND `spell_script_target`.`type` =1 AND `spell_script_target`.`targetEntry` =17253;