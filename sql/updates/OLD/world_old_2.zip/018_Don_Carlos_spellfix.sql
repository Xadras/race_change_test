/*
Don Carlos Guerrero Summon Spellfix
*/
UPDATE `creature_ai_scripts` SET `event_type`='0', `event_flags`='0' WHERE (`id`='2813202') LIMIT 1;
