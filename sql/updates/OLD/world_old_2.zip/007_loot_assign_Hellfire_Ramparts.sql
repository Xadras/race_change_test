/*
Bei einigen Creaturen war der Loot Template fast identisch, für diese habe ich halt keine neuen geschreiben
*/

UPDATE `creature_template` SET `lootid`='18053' WHERE (`entry`='18048') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18053' WHERE (`entry`='18049') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18053' WHERE (`entry`='18050') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18053' WHERE (`entry`='18051') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18053' WHERE (`entry`='18052') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18053' WHERE (`entry`='18053') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18053' WHERE (`entry`='18054') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18055' WHERE (`entry`='18055') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18053' WHERE (`entry`='18057') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18055' WHERE (`entry`='18058') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18059' WHERE (`entry`='18059') LIMIT 1;
UPDATE `creature_template` SET `lootid`='18435' WHERE (`entry`='18435') LIMIT 1;



