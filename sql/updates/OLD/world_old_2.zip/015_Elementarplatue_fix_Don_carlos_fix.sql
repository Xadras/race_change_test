/*
Guerrero NPC Template fix
*/

UPDATE `creature_template` SET `minhealth`='10000', `maxhealth`='12000', `armor`='3000', `faction_A`='14', `faction_H`='14', `mindmg`='250', `maxdmg`='750', `attackpower`='500', `baseattacktime`='1500' WHERE (`entry`='28163') LIMIT 1;
/*
Raging Fire Soul Mana fix
*/
UPDATE `creature_template` SET `minmana`='4000',`maxmana`='4000', `dmgschool`='2', `resistance1`='0', `resistance2`='32000' WHERE (`entry`='22311') LIMIT 1;

/*
Storming Wind Ripper Event Fix
*/
UPDATE `creature_template` SET `dmgschool`='3', `resistance3`='32000' WHERE (`entry`='22310') LIMIT 1;

/*
Crashing Wave Spirit Event Fix
*/
UPDATE `creature_template` SET `dmgschool`='4', `resistance4`='32000', `AIName`='EventAI' WHERE(`entry`='22309') LIMIT 1;

/*
Spellfix Summon Guerrero by Don Carlos

UPDATE `creature_ai_scripts` SET `action1_param2`='5' WHERE (`id`='2813202') LIMIT 1; /muss noch in gruppe auf den ptr getestet werden
*/
/*
Lootfix for Don Carlos
*/

UPDATE `creature_loot_template` SET `ChanceOrQuestChance`='-20' WHERE (`entry`='28132') AND (`item`='38329') LIMIT 1;
UPDATE `creature_loot_template` SET `ChanceOrQuestChance`='-31' WHERE (`entry`='91598') AND (`item`='38329') LIMIT 1;


/*
Spellfix for Storming Wind Ripper
*/
INSERT INTO `creature_ai_scripts` (`id`, `entryOrGUID`, `event_type`, `event_inverse_phase_mask`, `event_chance`, `event_flags`, `event_param1`, `event_param2`, `event_param3`, `event_param4`, `action1_type`, `action1_param1`, `action1_param2`, `action1_param3`, `action2_type`, `action2_param1`, `action2_param2`, `action2_param3`, `action3_type`, `action3_param1`, `action3_param2`, `action3_param3`, `comment`) VALUES ('4334035', '22310', '1', '0', '100', '1', '1000', '1000', '60000', '60000', '11', '12550', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', 'Cast Blitzschlagschild');
INSERT INTO `creature_ai_scripts` (`id`, `entryOrGUID`, `event_type`, `event_inverse_phase_mask`, `event_chance`, `event_flags`, `event_param1`, `event_param2`, `event_param3`, `event_param4`, `action1_type`, `action1_param1`, `action1_param2`, `action1_param3`, `action2_type`, `action2_param1`, `action2_param2`, `action2_param3`, `action3_type`, `action3_param1`, `action3_param2`, `action3_param3`, `comment`) VALUES ('4334034', '22310', '0', '0', '100', '3', '1000', '1500', '3500', '4500', '11', '20295', '1', '0', '23', '1', '0', '0', '0', '0', '0', '0', 'Cast Blitzschlag');

/*
Spellfix for Crashing Wave Spirit
*/
INSERT INTO `creature_ai_scripts` (`id`, `entryOrGUID`, `event_type`, `event_inverse_phase_mask`, `event_chance`, `event_flags`, `event_param1`, `event_param2`, `event_param3`, `event_param4`, `action1_type`, `action1_param1`, `action1_param2`, `action1_param3`, `action2_type`, `action2_param1`, `action2_param2`, `action2_param3`, `action3_type`, `action3_param1`, `action3_param2`, `action3_param3`, `comment`) VALUES ('4334033', '22309', '0', '0', '100', '3', '2000', '2000', '6000', '6000', '11', '34425', '4', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Cast Wasserschuss');


/*
Spellfix for Ragin Fire Soul
*/
INSERT INTO `creature_ai_scripts` (`id`, `entryOrGUID`, `event_type`, `event_inverse_phase_mask`, `event_chance`, `event_flags`, `event_param1`, `event_param2`, `event_param3`, `event_param4`, `action1_type`, `action1_param1`, `action1_param2`, `action1_param3`, `action2_type`, `action2_param1`, `action2_param2`, `action2_param3`, `action3_type`, `action3_param1`, `action3_param2`, `action3_param3`, `comment`) VALUES ('4334037', '22311', '0', '0', '100', '3', '2000', '2000', '4500', '4500', '11', '10151', '1', '0', '23', '1', '0', '0', '0', '0', '0', '0', 'Cast Feuerball Rang 11');

/*
Spawn 2 Storming Wind Ripper
*/
INSERT INTO `creature` VALUES (16800085, 22310, 530, 1, 0, 0, -888.137, 6391.72, 199.059, 3.90619, 300, 0, 0, 7956, 3231, 0, 0);
INSERT INTO `creature` VALUES (16800086, 22310, 530, 1, 0, 0, -707.569, 6357.68, 171.682, 5.56257, 300, 0, 0, 7956, 3231, 0, 0);

/*
Finish Fix
*/